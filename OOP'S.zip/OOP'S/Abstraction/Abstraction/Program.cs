﻿using System;

namespace Abstraction
{
    abstract class Abs
    {
        public abstract void print();
        public void print1()
        {
            Console.WriteLine("Abstract Class Normal Function");
        }
    }

    class child:Abs
    {
         public override void print()
        {
            Console.WriteLine("Abstract Function Overide in Child Class");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            child C=new child();

            C.print();
            C.print1();
        }
    }
}
