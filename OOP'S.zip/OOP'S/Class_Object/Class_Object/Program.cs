﻿using System;

namespace Class_Object
{
    class Demo
    {
        public void fun()
        {
            Console.WriteLine("Hii normal Class Function");
        }
    }

    static class Demo2
    {
        static public void fun2()
        {
            Console.WriteLine("Hii Static Class Function");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Demo obj=new Demo();

            obj.fun();
            
            Demo2.fun2 ();
            
            Console.ReadKey();
        }
    }
}
