﻿using System;

namespace Constant_ReadOnly
{
        class Program
    {
        public const int a = 100;
        readonly int b = 200;

        public Program(int n)
        {
            b = n;
        }
        static void Main(string[] args)
        {
            Program p = new Program(300);

            Console.WriteLine(p.b);
            Console.WriteLine(a);
        }
    }
}
