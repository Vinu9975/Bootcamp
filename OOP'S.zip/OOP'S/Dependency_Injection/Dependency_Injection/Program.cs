﻿using System;

namespace Dependency_Injection
{
    

    interface I1
    {
         void Dis();
    }


    class Child : I1
    {
       
        void I1.Dis()
        {
            Console.WriteLine("InterFace Method Deffine in Child Class");
        }
    }

    //-------------------constrtor Injection----------------------
    class Test
    {
        private I1 _a;
        public Test(I1 _a )
        {
            this._a = _a;
        }

        public void dis()
        {
            _a.Dis();
        }
    }

    //--------------Method Injection--------------------

    class demo
    {
        private I1 _a;
        
        public void print(I1 _a)
        {
            this._a= _a;
            _a.Dis();
        }
    }

    // --------------Property Injection--------------------

    class Pory
    {
        int a;
        string s;
        public Pory(int a,string v)
        {
            this.a= a;
            this.s= v;
        }

        public void print()
        {
            Console.WriteLine(a);
            Console.WriteLine(s);
        }
    }
    internal class Program
    {
        
        static void Main(string[] args)
        {
            //--------------Constrtor Injection--------------------
            Console.WriteLine("interface Method Call by using Constrtor Injection ");
            Test V;
            V=new Test(new Child());
            V.dis();

            //--------------Method Injection--------------------
            Console.WriteLine("interface Method Call by using Method Injection ");
            demo v1= new demo();
            v1.print(new Child());

            // --------------Property Injection--------------------
            Console.WriteLine(" using Property Injection ");
            Pory p = new Pory(10,"vishnu");
            p.print();


            Console.ReadKey();
        }
    }
}
