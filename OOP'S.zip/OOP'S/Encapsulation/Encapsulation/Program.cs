﻿using System;

namespace Encapsulation
{
    class student
    {
        private String name;
        private int age;

        public void getname()
        {
            Console.WriteLine("Name of Student is " + name);
            Console.WriteLine("Age of Student is " + age);

        }

        public void setname(string name)
        {
            this.name= name;
        }
        public void setage(int age)
        {
            this.age = age;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            student s= new student();
            s.setname("Vishnu");
            s.setage(20);

            s.getname();

        }
    }
}
