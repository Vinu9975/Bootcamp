﻿using System;

namespace Inheritance
{

    
    class Parent
    {
        public void fun()
        {
            Console.WriteLine("Parent Class Method");
        }
    }
    class child:Parent
    {
        public void fun1()
        {
            Console.WriteLine("child Class Method");
        }
    }

    class SubChild:child
    {
        public void fun2()
        {
            Console.WriteLine("SubChild Class Method");
        }

    }

    interface Iclass
    {
        void Demo1();

    }
    interface I2class
    {
        void Demo1();
        
    }

    class ClassInterface : Iclass, I2class
    {
        
        void Iclass.Demo1()
        {
            Console.WriteLine("Interface 1 Method Call");
        }
        void I2class.Demo1()
        {
            Console.WriteLine("Interface 2 Method Call");
        }

        public void Demo()
        {
            Console.WriteLine("ClassInterface Method Call");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            SubChild C1 =new SubChild();
            C1.fun();
            C1.fun1();
            C1.fun2();

            Iclass CI=new ClassInterface();
            CI.Demo1();

            I2class CI2=new ClassInterface();
            CI2.Demo1();

            ClassInterface CI3 =new ClassInterface();
            CI3.Demo();


        }
    }
}
