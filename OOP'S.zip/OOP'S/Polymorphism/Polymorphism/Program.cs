﻿using System;

namespace Polymorphism
{
    class Additation
    {
        public void add(int a, int b)
        {
            Console.WriteLine(a+b);
        }
        public void add(int a, float b)
        {
            Console.WriteLine(a + b);
        }

        public void add(float a, float b)
        {
            Console.WriteLine(a + b);
        }

    }

    abstract class Abs
    {
       abstract public void AbsFun();
    }

    class AbsChild:Abs
    {
        public override void AbsFun()
        {
            Console.WriteLine("Abstract method override in child class ");    
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Compile Time Polymorphism
            Console.WriteLine("-------------Compile Time Polymorphism--------------");
            int v = 30;
            Additation A=new Additation();

            A.add(10,20);   //pass direct value
            A.add(v,30.4f); //pass Variable & Float value
            A.add(45.76f, 30.45f);  //pass Float value

            //Run Time Polymorphism
            Console.WriteLine("-------------Run Time Polymorphism--------------");
            AbsChild B=new AbsChild();

            B.AbsFun();

            Console.ReadKey();

        }
    }
}
