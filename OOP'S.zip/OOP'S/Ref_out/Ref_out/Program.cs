﻿using System;

namespace Ref_out
{
    internal class Program
    {
        static public void demo1(ref int a)
        {
            a = 100;
            Console.WriteLine(a);
        }
        static public void demo2(ref int b)
        {
            b = 1000;
            Console.WriteLine(b);
        }
        static void Main(string[] args)
        {
            int v1 = 200;
            int v2 =  300  ;

            Program.demo1(ref v1);
            Program.demo2(ref v2);
            
           
            

            Console.ReadKey();

        }
    }
}
